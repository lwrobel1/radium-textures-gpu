var searchData=
[
  ['g_363',['g',['../structcuttlefish_1_1_color_r_g_b16.html#a166fc1dc75ac32bacdcb8d73d3de301a',1,'cuttlefish::ColorRGB16::g()'],['../structcuttlefish_1_1_color_r_g_b_a16.html#a166fc1dc75ac32bacdcb8d73d3de301a',1,'cuttlefish::ColorRGBA16::g()'],['../structcuttlefish_1_1_color_r_g_bf.html#a8cf17d727651616de6f2b79ef32170cd',1,'cuttlefish::ColorRGBf::g()'],['../structcuttlefish_1_1_color_r_g_b_af.html#a8cf17d727651616de6f2b79ef32170cd',1,'cuttlefish::ColorRGBAf::g()'],['../structcuttlefish_1_1_color_r_g_b_ad.html#ab30c765b9be1b7776c97c899a12a66bb',1,'cuttlefish::ColorRGBAd::g()'],['../structcuttlefish_1_1_texture_1_1_color_mask.html#ac4ffa8a5fc624085fd4582a77f1aceea',1,'cuttlefish::Texture::ColorMask::g()']]]
];

var searchData=
[
  ['facecount_306',['faceCount',['../classcuttlefish_1_1_texture.html#ae09984b6adfd1373ac82566161dee014',1,'cuttlefish::Texture']]],
  ['filetype_307',['fileType',['../classcuttlefish_1_1_texture.html#a5622b6331227c00f44849ba19cff70f2',1,'cuttlefish::Texture']]],
  ['fliphorizontal_308',['flipHorizontal',['../classcuttlefish_1_1_image.html#a8706000a04f9e0c522fd5c8a511a533f',1,'cuttlefish::Image']]],
  ['flipvertical_309',['flipVertical',['../classcuttlefish_1_1_image.html#a0b633460ec765dcf83fe6fa3ab5fbbc9',1,'cuttlefish::Image']]],
  ['format_310',['format',['../classcuttlefish_1_1_image.html#a7047a267776924cf166c301310f03a2c',1,'cuttlefish::Image::format()'],['../classcuttlefish_1_1_texture.html#a7047a267776924cf166c301310f03a2c',1,'cuttlefish::Texture::format()']]]
];

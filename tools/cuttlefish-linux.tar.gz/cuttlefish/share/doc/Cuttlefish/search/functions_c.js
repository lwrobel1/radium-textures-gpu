var searchData=
[
  ['redmask_342',['redMask',['../classcuttlefish_1_1_image.html#a822302f36c90727f0b6113e084a6d2c8',1,'cuttlefish::Image']]],
  ['redshift_343',['redShift',['../classcuttlefish_1_1_image.html#a2334c28bcb7d683e604f601d00314707',1,'cuttlefish::Image']]],
  ['reset_344',['reset',['../classcuttlefish_1_1_image.html#ad20897c5c8bd47f5d4005989bead0e55',1,'cuttlefish::Image::reset()'],['../classcuttlefish_1_1_texture.html#ad20897c5c8bd47f5d4005989bead0e55',1,'cuttlefish::Texture::reset()']]],
  ['resize_345',['resize',['../classcuttlefish_1_1_image.html#a43ef991bc897b367e743d9da3e77fc8e',1,'cuttlefish::Image']]],
  ['rotate_346',['rotate',['../classcuttlefish_1_1_image.html#ad7b4a5546e933397db5110b8c8a94503',1,'cuttlefish::Image']]]
];

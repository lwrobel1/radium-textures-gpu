var searchData=
[
  ['float_448',['Float',['../classcuttlefish_1_1_image.html#ab4e88c89b3b7ea1735996cc4def22d58a22ae0e2b89e5e3d477f988cc36d3272b',1,'cuttlefish::Image::Float()'],['../classcuttlefish_1_1_texture.html#a1d1cfd8ffb84e947f82999c682b666a7a22ae0e2b89e5e3d477f988cc36d3272b',1,'cuttlefish::Texture::Float()']]]
];

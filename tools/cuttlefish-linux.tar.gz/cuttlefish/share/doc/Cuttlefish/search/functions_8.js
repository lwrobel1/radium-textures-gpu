var searchData=
[
  ['lineartosrgb_327',['linearToSRGB',['../_color_8h.html#ac3cf990d50f77d058abfdd442be6f66c',1,'cuttlefish']]],
  ['load_328',['load',['../classcuttlefish_1_1_image.html#a52650b3b5caaf80ae4bca4b239a8e629',1,'cuttlefish::Image::load(const char *fileName, ColorSpace colorSpace=ColorSpace::Linear)'],['../classcuttlefish_1_1_image.html#a7ba2b7d115233d74315be57ebcf27d5e',1,'cuttlefish::Image::load(std::istream &amp;stream, ColorSpace colorSpace=ColorSpace::Linear)'],['../classcuttlefish_1_1_image.html#ab2b5d643704cb8fe058de598015da05b',1,'cuttlefish::Image::load(const void *data, std::size_t size, ColorSpace colorSpace=ColorSpace::Linear)']]]
];

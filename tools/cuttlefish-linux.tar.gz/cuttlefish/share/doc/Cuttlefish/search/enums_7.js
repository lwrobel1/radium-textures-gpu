var searchData=
[
  ['resizefilter_381',['ResizeFilter',['../classcuttlefish_1_1_image.html#a3208e2d9101e5a94a98d3135f9087d36',1,'cuttlefish::Image']]],
  ['rotateangle_382',['RotateAngle',['../classcuttlefish_1_1_image.html#a6c97fda07b93e57c51529b7f40235120',1,'cuttlefish::Image']]]
];

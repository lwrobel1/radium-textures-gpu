var searchData=
[
  ['gray16_449',['Gray16',['../classcuttlefish_1_1_image.html#ab4e88c89b3b7ea1735996cc4def22d58a2a6ec0dac8730c09dba12f860dbbad12',1,'cuttlefish::Image']]],
  ['gray8_450',['Gray8',['../classcuttlefish_1_1_image.html#ab4e88c89b3b7ea1735996cc4def22d58ac8cfe3d00282445878661f32adca48ef',1,'cuttlefish::Image']]],
  ['green_451',['Green',['../classcuttlefish_1_1_image.html#a1ce9b523fd4f3b5bbcadcd796183455aad382816a3cbeed082c9e216e7392eed1',1,'cuttlefish::Image']]]
];

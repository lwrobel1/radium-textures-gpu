var searchData=
[
  ['timing_5fcontext_0',['timing_context',['../structnvtt_1_1_encode_settings.html#a30fd57442fb2e4e4ec19ea00ba17cac3',1,'nvtt::EncodeSettings']]]
];

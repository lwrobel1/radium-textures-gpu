var searchData=
[
  ['d3d9format_0',['d3d9Format',['../structnvtt_1_1_compression_options.html#a8f9ed2a569d47cfbaab30f1abac801d5',1,'nvtt::CompressionOptions']]],
  ['data_1',['data',['../structnvtt_1_1_surface.html#a40c605957799d4ea31682d5982e1036d',1,'nvtt::Surface::data() const'],['../structnvtt_1_1_surface.html#acad4388ee26550c4aae145b99d0ac563',1,'nvtt::Surface::data()']]],
  ['demultiplyalpha_2',['demultiplyAlpha',['../structnvtt_1_1_surface.html#a907f237e7825d33836d253f21fca2274',1,'nvtt::Surface']]],
  ['depth_3',['depth',['../structnvtt_1_1_surface.html#a6ceabda2b08248eecbe991b708ae52fb',1,'nvtt::Surface']]],
  ['diff_4',['diff',['../namespacenvtt.html#a1781708d38918b6eda9165fb5f9c10c1',1,'nvtt']]]
];

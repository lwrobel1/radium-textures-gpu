var searchData=
[
  ['channel_5finterleave_0',['channel_interleave',['../structnvtt_1_1_ref_image.html#a02003d295994cf1535f0e1864f048592',1,'nvtt::RefImage']]],
  ['channel_5fswizzle_1',['channel_swizzle',['../structnvtt_1_1_ref_image.html#ad88dd307a6a2b111d6db66193c530f5c',1,'nvtt::RefImage']]]
];

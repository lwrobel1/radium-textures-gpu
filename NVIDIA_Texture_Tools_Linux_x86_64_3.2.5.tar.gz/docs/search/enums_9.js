var searchData=
[
  ['resizefilter_0',['ResizeFilter',['../namespacenvtt.html#a3607100ce561fdaa3859abd0f05878c7',1,'nvtt']]],
  ['roundmode_1',['RoundMode',['../namespacenvtt.html#a673a22796ec42ae50e14ab1ed6906bd5',1,'nvtt']]]
];

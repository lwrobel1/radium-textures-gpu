var searchData=
[
  ['encodesettings_0',['EncodeSettings',['../structnvtt_1_1_encode_settings.html',1,'nvtt']]],
  ['errorhandler_1',['ErrorHandler',['../structnvtt_1_1_error_handler.html',1,'nvtt']]]
];

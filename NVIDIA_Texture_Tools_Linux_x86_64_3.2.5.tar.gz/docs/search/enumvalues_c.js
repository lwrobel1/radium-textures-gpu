var searchData=
[
  ['wrapmode_5fclamp_0',['WrapMode_Clamp',['../namespacenvtt.html#a04c40c16cdcde3c6c3f2e7081777a146ad11969ec5e66b90e4c7c55a2aa2542f0',1,'nvtt']]],
  ['wrapmode_5fmirror_1',['WrapMode_Mirror',['../namespacenvtt.html#a04c40c16cdcde3c6c3f2e7081777a146a550cb72f50d0b0571a2db0badfb44083',1,'nvtt']]],
  ['wrapmode_5frepeat_2',['WrapMode_Repeat',['../namespacenvtt.html#a04c40c16cdcde3c6c3f2e7081777a146aa974b2999b7a9ca5a0cbf5ebf52ecea9',1,'nvtt']]]
];

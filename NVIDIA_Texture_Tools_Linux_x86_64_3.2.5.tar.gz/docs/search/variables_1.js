var searchData=
[
  ['data_0',['data',['../structnvtt_1_1_ref_image.html#a28f7946a03f3887f191c097025fcc916',1,'nvtt::RefImage']]],
  ['depth_1',['depth',['../structnvtt_1_1_ref_image.html#af8ba0b4ec841b4cbc70132c84ab94ffb',1,'nvtt::RefImage']]]
];

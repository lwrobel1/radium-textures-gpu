var searchData=
[
  ['packnormals_0',['packNormals',['../structnvtt_1_1_surface.html#aea61a9ee80443c5ad863287499d2e081',1,'nvtt::Surface']]],
  ['premultiplyalpha_1',['premultiplyAlpha',['../structnvtt_1_1_surface.html#a4cf3bba837ea826fdf107a9c46935854',1,'nvtt::Surface']]],
  ['printrecords_2',['PrintRecords',['../structnvtt_1_1_timing_context.html#a139ebebd736df993adb0c46c8a7d2abd',1,'nvtt::TimingContext']]]
];

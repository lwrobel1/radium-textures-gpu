var searchData=
[
  ['quality_0',['quality',['../structnvtt_1_1_encode_settings.html#a895a671dfbc3a3483f77a35bc25ab81a',1,'nvtt::EncodeSettings']]]
];

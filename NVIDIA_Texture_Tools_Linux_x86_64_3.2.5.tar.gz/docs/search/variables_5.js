var searchData=
[
  ['num_5fchannels_0',['num_channels',['../structnvtt_1_1_ref_image.html#a775ea94efce207fea55be6fa1e0ce975',1,'nvtt::RefImage']]]
];

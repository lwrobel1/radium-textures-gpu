var searchData=
[
  ['width_0',['width',['../structnvtt_1_1_ref_image.html#ac4cbe541b040b5ae34b925b4cebec75c',1,'nvtt::RefImage']]]
];

var searchData=
[
  ['rgb_5fpixel_5ftype_0',['rgb_pixel_type',['../structnvtt_1_1_encode_settings.html#add55a15cce8a2dd4c05e461adb76ae93',1,'nvtt::EncodeSettings']]]
];

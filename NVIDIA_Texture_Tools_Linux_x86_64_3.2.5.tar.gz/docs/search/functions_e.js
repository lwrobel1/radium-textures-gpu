var searchData=
[
  ['range_0',['range',['../structnvtt_1_1_surface.html#afc8a14675ef0cbc891bfe839d29a1c29',1,'nvtt::Surface::range()'],['../structnvtt_1_1_cube_surface.html#ac91a095f84d68036c44c9b9097fed018',1,'nvtt::CubeSurface::range()']]],
  ['reconstructnormals_1',['reconstructNormals',['../structnvtt_1_1_surface.html#ad186ad17e1f204e00ecb54e018814cad',1,'nvtt::Surface']]],
  ['reset_2',['reset',['../structnvtt_1_1_compression_options.html#a351a5a3cdc0e78080b6c987bd08d2ffa',1,'nvtt::CompressionOptions::reset()'],['../structnvtt_1_1_output_options.html#a095170d61a3d5210f0f24037b2a642b4',1,'nvtt::OutputOptions::reset()'],['../structnvtt_1_1_surface_set.html#aed0963357b93e176185096cc77e92ed3',1,'nvtt::SurfaceSet::reset()']]],
  ['resize_3',['resize',['../structnvtt_1_1_surface.html#aa8b2bd544a72fb7c60e0106c6f870893',1,'nvtt::Surface::resize(int w, int h, int d, ResizeFilter filter, TimingContext *tc=0)'],['../structnvtt_1_1_surface.html#a013d651c695516e8fdbdf7634573918a',1,'nvtt::Surface::resize(int w, int h, int d, ResizeFilter filter, float filterWidth, const float *params=0, TimingContext *tc=0)'],['../structnvtt_1_1_surface.html#ac459aa4c41f41ec0f615b6352e3262c2',1,'nvtt::Surface::resize(int maxExtent, RoundMode mode, ResizeFilter filter, TimingContext *tc=0)'],['../structnvtt_1_1_surface.html#a6f66cd503c0b7fd8667cfc7acca170e4',1,'nvtt::Surface::resize(int maxExtent, RoundMode mode, ResizeFilter filter, float filterWidth, const float *params=0, TimingContext *tc=0)']]],
  ['resize_5fmake_5fsquare_4',['resize_make_square',['../structnvtt_1_1_surface.html#af84c67783861084298893fa54f031624',1,'nvtt::Surface']]],
  ['rmsalphaerror_5',['rmsAlphaError',['../namespacenvtt.html#a91b64d4539ee2f98379249975d2b277c',1,'nvtt']]],
  ['rmserror_6',['rmsError',['../namespacenvtt.html#ad5a3afaec760ccfaddbc0d41a30ea3b4',1,'nvtt']]],
  ['rmstonemappederror_7',['rmsToneMappedError',['../namespacenvtt.html#a37bcafcdac02a84ac84306a758276b39',1,'nvtt']]]
];

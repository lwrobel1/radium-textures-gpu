var searchData=
[
  ['uint8_0',['UINT8',['../namespacenvtt.html#ae939a4f095a98e5176153b81dba28321a2af64236612722b24eb2b58858257b4b',1,'nvtt']]],
  ['unfold_1',['unfold',['../structnvtt_1_1_cube_surface.html#a45848776776e5201ad27b5b93b0ef9de',1,'nvtt::CubeSurface']]],
  ['usecurrentdevice_2',['useCurrentDevice',['../namespacenvtt.html#a4331c366610258762f80c8a3d7ee6910',1,'nvtt']]],
  ['using_20the_20high_20level_20apis_3',['Using the high-level APIs',['../index.html#autotoc_md0',1,'']]],
  ['using_20the_20low_20level_20apis_4',['Using the low-level APIs',['../index.html#autotoc_md6',1,'']]]
];

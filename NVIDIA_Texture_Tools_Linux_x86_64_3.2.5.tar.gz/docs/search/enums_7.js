var searchData=
[
  ['pixeltype_0',['PixelType',['../namespacenvtt.html#accbc2d4c0396fc4e6d75d19e435c88ed',1,'nvtt']]]
];

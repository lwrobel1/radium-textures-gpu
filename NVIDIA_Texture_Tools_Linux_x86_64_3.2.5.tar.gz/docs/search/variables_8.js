var searchData=
[
  ['stype_0',['sType',['../structnvtt_1_1_encode_settings.html#aa6b2e005ca208719f853e6aa124d7f62',1,'nvtt::EncodeSettings']]]
];

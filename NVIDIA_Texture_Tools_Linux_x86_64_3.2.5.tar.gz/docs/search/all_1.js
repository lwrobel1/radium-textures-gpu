var searchData=
[
  ['a_20single_20file_0',['Compressing a single file',['../index.html#autotoc_md1',1,'']]],
  ['abs_1',['abs',['../structnvtt_1_1_surface.html#a737d13712fa657adb92a2bbb4e6619c6',1,'nvtt::Surface']]],
  ['addchannel_2',['addChannel',['../structnvtt_1_1_surface.html#a475066551f1fb973e9dadb21898a19d4',1,'nvtt::Surface']]],
  ['alphamode_3',['alphaMode',['../structnvtt_1_1_surface.html#a1ee2a5e77598e1801dbe683872fe1bae',1,'nvtt::Surface']]],
  ['alphamode_4',['AlphaMode',['../namespacenvtt.html#a258d3a85ebeb5cf05c98ce3b2441b172',1,'nvtt']]],
  ['alphamode_5fnone_5',['AlphaMode_None',['../namespacenvtt.html#a258d3a85ebeb5cf05c98ce3b2441b172a80b3682c42eec9a6dbc246872054c65a',1,'nvtt']]],
  ['alphamode_5fpremultiplied_6',['AlphaMode_Premultiplied',['../namespacenvtt.html#a258d3a85ebeb5cf05c98ce3b2441b172a1e907653d2f7ea2020bd95938aa17694',1,'nvtt']]],
  ['alphamode_5ftransparency_7',['AlphaMode_Transparency',['../namespacenvtt.html#a258d3a85ebeb5cf05c98ce3b2441b172ab064a6344180e25b06ff1e7cb7863d76',1,'nvtt']]],
  ['alphatestcoverage_8',['alphaTestCoverage',['../structnvtt_1_1_surface.html#a3b4cdb2773ea35b42ea460a2b4026cbe',1,'nvtt::Surface']]],
  ['angularerror_9',['angularError',['../namespacenvtt.html#abc944623c193bb0a1f8679a6f44a78e5',1,'nvtt']]],
  ['api_20introduction_10',['NVTT 3 - API Introduction',['../index.html',1,'']]],
  ['apis_11',['APIs',['../index.html#autotoc_md0',1,'Using the high-level APIs'],['../index.html#autotoc_md6',1,'Using the low-level APIs']]],
  ['append_12',['Append',['../structnvtt_1_1_batch_list.html#abdaeb97d4bb24d975f9a5354c120995b',1,'nvtt::BatchList']]],
  ['average_13',['average',['../structnvtt_1_1_surface.html#ae9ed55dcc5f3f3d297e02872164be2d5',1,'nvtt::Surface::average()'],['../structnvtt_1_1_cube_surface.html#a992d21f3e8f4ca7c83c3a7491764892b',1,'nvtt::CubeSurface::average()']]]
];
